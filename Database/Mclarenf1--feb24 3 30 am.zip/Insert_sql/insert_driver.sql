insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (2, 'Lois', 'Deeley', 2, 'Canada', '1976/02/21');
insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (3, 'Niles', 'Rouff', 3, 'United States', '1977/11/25');
insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (4, 'Catriona', 'Scudder', 4, 'United States', '1980/07/02');
insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (5, 'Alessandra', 'Gages', 5, 'United States', '1984/07/20');
insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (6, 'Averell', 'Cyson', 6, 'United States', '1997/08/18');
insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (7, 'Enrico', 'Nanson', 7, 'Canada', '1999/09/08');
insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (8, 'Sayre', 'Largent', 8, 'Canada', '1974/11/11');
insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (9, 'Thor', 'Mattholie', 9, 'Belgium', '1974/02/15');
insert into Driver (driver_id, first_name, last_name, car_number, country, dob) values (10, 'Cassius', 'Burnes', 10, 'Canada', '1982/11/07');