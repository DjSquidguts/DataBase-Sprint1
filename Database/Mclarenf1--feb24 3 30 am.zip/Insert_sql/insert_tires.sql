insert into tires (tire_id, brand, compound, weather) values (1, 'Goodyear', '3826dw6k5', 'DRY HOT');
insert into tires (tire_id, brand, compound, weather) values (2, 'Goodyear', '17urvu2x6', 'DRY COLD');
insert into tires (tire_id, brand, compound, weather) values (3, 'Goodyear', '89j6zx704', 'WET');
insert into tires (tire_id, brand, compound, weather) values (4, 'Goodyear', '78nj7y9n1', 'Aggressive');
insert into tires (tire_id, brand, compound, weather) values (5, 'Goodyear', '41oror6v2', 'cold');
insert into tires (tire_id, brand, compound, weather) values (6, 'Goodyear', '3640in887', 'cold wet');
insert into tires (tire_id, brand, compound, weather) values (7, 'Continental', '3640co887', 'cold wet');
insert into tires (tire_id, brand, compound, weather) values (8, 'Continental', '7740co111', 'wet');