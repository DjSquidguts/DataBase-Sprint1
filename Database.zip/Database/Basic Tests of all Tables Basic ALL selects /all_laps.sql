SELECT lap_id, lap_time
	FROM public.laps;