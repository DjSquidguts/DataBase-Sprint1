SELECT driver_id, first_name, last_name, car_number, country, dob
	FROM public.driver;