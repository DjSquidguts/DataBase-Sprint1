SELECT wing_rear_id, degree
	FROM public.wing_rear;