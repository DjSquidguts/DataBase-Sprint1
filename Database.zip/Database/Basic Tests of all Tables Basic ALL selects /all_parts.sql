SELECT part_id, engine_serial, wing_id, "wing_ rear_id", trans_id, description
	FROM public.parts;