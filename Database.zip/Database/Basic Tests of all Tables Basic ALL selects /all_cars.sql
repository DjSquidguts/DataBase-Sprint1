SELECT car_id, engine_id, weight, make, chasis_id, wing_id, wing_rear_id, tire_id, parts_id
	FROM public.cars;