SELECT race_id, loc_id, final_pos, driver_id, car_id, tire_id
	FROM public.race_results;