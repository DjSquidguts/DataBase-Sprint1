SELECT p_session_id, date, driver_id, ambient_temp, track_temp, lap_id, car_id
	FROM public.practice;