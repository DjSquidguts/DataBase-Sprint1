SELECT loc_id, loc_name, country, city, track_type
	FROM public.location;