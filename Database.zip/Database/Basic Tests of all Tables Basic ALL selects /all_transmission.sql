SELECT trans_id, serial, details
	FROM public.transmission;