SELECT tire_id, brand, compound, weather
	FROM public.tires;