SELECT wing_id, degree
	FROM public.wing_front;