insert into cars (car_id, engine_id, weight, make, chasis_id) values (1, 'SCBDR33W18C136384', 1665, 'Galaxie', 'com.vimeo');
insert into cars (car_id, engine_id, weight, make, chasis_id) values (2, 'WAUHMAFC6EN149731', 1681, 'Navajo', 'cq.Aerified');
insert into cars (car_id, engine_id, weight, make, chasis_id) values (3, 'WAUKF98E08A368564', 1678, 'Escort', 'com.Latlux');
insert into cars (car_id, engine_id, weight, make, chasis_id) values (4, 'WAUKD98P06A818203', 1678, 'Galaxie', 'ow.Sonair');
insert into cars (car_id, engine_id, weight, make, chasis_id) values (5, '1N4AL3AP0EC523216', 1678, 'Galaxie', 'netPannier');