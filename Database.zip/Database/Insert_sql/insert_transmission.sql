insert into transmission (trans_id, serial) values (1, 'SCFEFBAC9AG380961');
insert into transmission (trans_id, serial) values (2, 'QBAFU7C52BC162175');
insert into transmission (trans_id, serial) values (3, 'BAUDF68EX5A935866');
insert into transmission (trans_id, serial) values (4, 'KAUEKAFB3AN256293');
insert into transmission (trans_id, serial) values (5, 'WBA4A7C56FG584867');

