insert into practice (p_session_id, date, ambient_temp, track_temp) values (1, '2022-02-18', 28, 22);
insert into practice (p_session_id, date, ambient_temp, track_temp) values (2, '2022-02-17', 23, 25);
insert into practice (p_session_id, date, ambient_temp, track_temp) values (3, '2022-02-19', 23, 22);
insert into practice (p_session_id, date, ambient_temp, track_temp) values (4, '2022-02-19', 28, 22);
insert into practice (p_session_id, date, ambient_temp, track_temp) values (5, '2022-02-19', 25, 24);