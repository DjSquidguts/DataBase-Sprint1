DELETE FROM public.laps
	WHERE lap_id = 666;